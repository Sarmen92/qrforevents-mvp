import Layout from '../components/Layout';

export default function RSVP() {
  return (
    <Layout>
      <h2>RSVP Landing Page</h2>
      <p>Guests will see event details here and RSVP Yes/No.</p>
      <p>Gift registry links with affiliate tags will also appear here.</p>
    </Layout>
  );
}
